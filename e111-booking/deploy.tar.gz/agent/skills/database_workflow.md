# Database Management Skill

## Context
We are using **SQLite** locally (`file:./dev.db`) managed by **Prisma ORM**.

## Standard Workflows

### 1. Schema Changes
When you modify `prisma/schema.prisma`:
1. Run Migration: `npx prisma migrate dev --name <migration_name>`
2. This automatically generates the client and seeds the executing database.

### 2. Seeding Data
To populate the database with initial/test data:
- Script location: `prisma/seed.ts`
- **Command**: `npx prisma db seed`
- *Note*: Ensure `package.json` has `"prisma": { "seed": "npx tsx prisma/seed.ts" }`

### 3. Full Reset (Emergency Button)
If the database schema is out of sync or migration history is corrupted (e.g., switched from Postgres):
1. Delete `prisma/migrations/` folder.
2. Delete `prisma/dev.db`.
3. Run: `npx prisma migrate dev --name init_reset`

## Troubleshooting
- **Error: P3019 (Provider switch)**: You must delete `prisma/migrations` and the `.db` file to reset history.
- **Client Not Found**: Run `npx prisma generate` and restart the Nuxt server.
