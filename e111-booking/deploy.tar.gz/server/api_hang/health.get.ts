export default defineEventHandler(() => ({ success: true }))
