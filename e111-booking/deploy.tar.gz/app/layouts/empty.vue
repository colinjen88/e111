<template>
  <div class="empty-layout">
    <slot />
  </div>
</template>
