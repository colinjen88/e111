<template>
  <div style="font-family: sans-serif; max-width: 600px; margin: 40px auto; text-align: center;">
    <h1 style="color: #d73324;">🎉 E111 Booking System</h1>
    <p style="color: #666;">Nuxt is working!</p>
    <NuxtLink to="/booking" style="display: inline-block; margin-top: 20px; padding: 12px 24px; background: #d73324; color: white; text-decoration: none; border-radius: 8px;">
      開始預約
    </NuxtLink>
  </div>
</template>
