-- AlterTable
ALTER TABLE "Staff" ADD COLUMN     "password" TEXT;
