<script setup lang="ts">
// In your page components:
definePageMeta({
  middleware: ["auth"]
})
</script>
