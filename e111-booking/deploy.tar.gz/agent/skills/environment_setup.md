# Environment & Debugging Skill

## Architecture specific rules
- **Nuxt 4 Directory Structure**:
  - `pages/` -> `app/pages/`
  - `components/` -> `app/components/`
  - `server/` -> **ROOT/server/** (Do NOT move to app!)
  
## Common Errors & Fixes

### 1. "Page not found: /api/..."
- **Cause**: Server directory is misplaced or not being scanned.
- **Fix**: Ensure `server/` is at the project root. Check `nuxt.config.ts` if custom API paths are set (usually not needed).

### 2. Infinite Loading / White Screen
- **Cause**: `app/app.vue` is blocking routing or missing `<NuxtPage />`. or `await useFetch` blocking navigation.
- **Fix**: 
  - Verify `app/app.vue` has `<NuxtPage />`.
  - Use `useLazyFetch` for non-critical data fetching in components.

### 3. Tailwind CSS Crash
- **Cause**: Installing `tailwindcss@4` with Nuxt modules designed for v3.
- **Fix**: Stick to `tailwindcss@3.x` and `@nuxtjs/tailwindcss`.

### 4. Windows Networking
- **Issue**: `localhost` connection refused.
- **Fix**: Use `127.0.0.1` or bind server to `0.0.0.0` (`--host 0.0.0.0`).
- **Check**: Run `node` test server to isolate if it's Nuxt or OS firewall.
