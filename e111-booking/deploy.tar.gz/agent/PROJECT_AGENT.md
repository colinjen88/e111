# E111-Booking Agent Knowledge Base

## 1. Project Overview
A booking system for a massage parlor ("金指藝"), built with the **Golden Stack**:
- **Framework**: Nuxt 3 (SSR + API)
- **Database**: SQLite (via Prisma ORM) - *Note: Switched from Postgres due to Docker issues*
- **Styling**: Tailwind CSS (v3) - *Note: Avoid v4 to prevent Nuxt module conflict*
- **State**: Vue Reactivity (Composition API)

## 2. Key Directories
- `app/` : Frontend Application (Nuxt 4 Structure)
    - `pages/` : Routing Pages
    - `components/` : Vue Components
    - `app.vue` : Root Component (Must contain `<NuxtPage />`)
- `server/` : Backend API (Nitro) **[MUST be at root, NOT in app/]**
    - `api/` : API Routes
    - `utils/` : Server Utilities (e.g. Prisma Client)
- `prisma/` : Database Schema & Seeds

## 3. Critical Commands
- **Dev Server**: `npm run dev` (Runs on port 2390)
- **Database Reset**: `npx prisma migrate dev --name reset` (Wipes DB & Re-seeds)
- **Seed Only**: `npx prisma db seed` (Run via `tsx`)

## 4. Known Pitfalls (READ THIS!)
1. **API 404**: Ensures `server/` is at PROJECT ROOT. Do not move it to `app/server`.
2. **Infinite Loading**: `app.vue` must replace `NuxtWelcome` with `<NuxtPage />`.
3. **Tailwind Conflict**: Do NOT install `tailwindcss@4`. Use v3 with `@nuxtjs/tailwindcss` or manual PostCSS config.
4. **Prisma Client**: `npx prisma generate` is required after schema changes. Restart dev server if API fails.
5. **Localhost Blocked**: If `localhost:2390` fails, use `127.0.0.1:2390` purely due to Windows networking quirks.
