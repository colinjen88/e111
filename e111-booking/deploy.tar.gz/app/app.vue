<template>
  <div class="antialiased text-gray-800 min-h-screen bg-gray-50">
    <NuxtRouteAnnouncer />
    <NuxtPage />
  </div>
</template>
