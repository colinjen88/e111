<script setup lang="ts">
useHead({
  title: '服務條款 - 御手國醫養生會館',
})
</script>

<template>
  <div class="max-w-4xl mx-auto py-12 px-6 font-sans text-gray-800 leading-relaxed">
    <h1 class="text-3xl font-serif font-bold text-brand-dark mb-8 border-b pb-4">服務條款</h1>
    
    <div class="space-y-6">
      <section>
        <h2 class="text-xl font-bold mb-2">1.認知與接受條款</h2>
        <p>御手國醫養生會館（以下簡稱「本會館」）係依據本服務條款提供預約服務（以下簡稱「本服務」）。當您使用本服務時，即表示您已閱讀、瞭解並同意接受本服務條款之所有內容。本會館有權於任何時間修改或變更本服務條款之內容，建議您隨時注意該等修改或變更。</p>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">2.會員/預約者之註冊義務</h2>
        <p>為了能使用本服務，您同意以下事項：</p>
        <ul class="list-disc pl-5 mt-2 space-y-1">
          <li>依本服務預約表單之提示提供您本人正確、最新及完整的資料。</li>
          <li>維持並更新您個人資料，確保其為正確、最新及完整。若您提供任何錯誤、不實或不完整的資料，本會館有權暫停或終止您的預約，並拒絕您使用本服務之全部或一部。</li>
        </ul>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">3.預約與取消政策</h2>
        <ul class="list-disc pl-5 mt-2 space-y-1">
          <li>預約成立後，若需取消或變更時間，請於預約時間前 2 小時透過本系統或致電分館辦理。</li>
          <li>若無故未到（No-Show）且未提前告知，本會館保留拒絕您未來預約之權利。</li>
          <li>本會館保留因天災、設備故障或其他不可抗力因素而取消預約之權利。</li>
        </ul>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">4.使用者的守法義務及承諾</h2>
        <p>您承諾絕不為任何非法目的或以任何非法方式使用本服務，並承諾遵守中華民國相關法規及一切使用網際網路之國際慣例。您若係中華民國以外之使用者，並同意遵守所屬國家或地域之法令。</p>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">5.服務之停止、中斷</h2>
        <p>本會館將依一般合理之技術及方式，維持本服務之正常運作。但於以下各項情況時，本會館有權可以停止、中斷提供本服務：</p>
        <ul class="list-disc pl-5 mt-2 space-y-1">
          <li>本會館網站電子通信設備進行必要之保養及施工時。</li>
          <li>發生突發性之電子通信設備故障時。</li>
          <li>本會館網站申請之電子通信服務被停止，無法提供服務時。</li>
          <li>因天災等不可抗力之因素或其他不可歸責於本會館致使本服務無法提供服務時。</li>
        </ul>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">6.準據法與管轄法院</h2>
        <p>本服務條款之解釋與適用，以及與本服務條款有關的爭議，均應依照中華民國法律予以處理，並以台灣台南地方法院為第一審管轄法院。</p>
      </section>
    </div>

    <div class="mt-12 text-center">
       <NuxtLink to="/" class="px-6 py-2 bg-brand-dark text-white rounded hover:bg-black transition-colors">返回首頁</NuxtLink>
    </div>
  </div>
</template>
