import { prisma } from '../../utils/prisma'
import { subDays, startOfDay, endOfDay, format } from 'date-fns'

export default defineEventHandler(async (event) => {
  try {
    // Admin Auth Check
    requireAdmin(event)

    const now = new Date()
    const thirtyDaysAgo = subDays(now, 30)

    // 1. Fetch bookings for last 30 days
    const bookings = await prisma.booking.findMany({
      where: {
        bookingDate: {
          gte: thirtyDaysAgo
        },
        status: {
          not: 'Cancelled' // Only count valid bookings
        }
      },
      select: {
        bookingDate: true,
        totalPrice: true,
        status: true
      }
    })

    // 2. Aggregate Daily Revenue
    const dailyRevenue: Record<string, number> = {}
    const dailyCount: Record<string, number> = {}

    // Initialize last 30 days with 0
    for (let i = 0; i <= 30; i++) {
      const dateStr = format(subDays(now, i), 'yyyy-MM-dd')
      dailyRevenue[dateStr] = 0
      dailyCount[dateStr] = 0
    }

    bookings.forEach(b => {
      const dateStr = format(new Date(b.bookingDate), 'yyyy-MM-dd')
      if (dailyRevenue[dateStr] !== undefined) {
        const price = Number(b.totalPrice)
        dailyRevenue[dateStr] += price
        dailyCount[dateStr] += 1
      }
    })

    const chartData = []
    for (let i = 29; i >= 0; i--) {
      const d = subDays(now, i)
      const dateStr = format(d, 'yyyy-MM-dd')
      chartData.push({
        date: format(d, 'MM/dd'),
        fullDate: dateStr,
        revenue: dailyRevenue[dateStr] || 0,
        count: dailyCount[dateStr] || 0
      })
    }

    // 3. Summary Stats (Today/Week/Month)
    // Today
    const todayStr = format(now, 'yyyy-MM-dd')
    const todayRevenue = dailyRevenue[todayStr] || 0
    const todayCount = dailyCount[todayStr] || 0

    // Total Month (Last 30 days sum)
    const totalRevenue = Object.values(dailyRevenue).reduce((a, b) => a + b, 0)
    const totalCount = Object.values(dailyCount).reduce((a, b) => a + b, 0)

    return {
      success: true,
      stats: {
        today: { revenue: todayRevenue, count: todayCount },
        month: { revenue: totalRevenue, count: totalCount },
      },
      chartData
    }

  } catch (error: any) {
    if (error.statusCode) throw error
    console.error('Stats Error:', error)
    throw createError({ statusCode: 500, statusMessage: 'Failed to fetch statistics' })
  }
})
