<template>
  <div class="h-full min-h-screen bg-brand-cream">
    <slot />
  </div>
</template>
