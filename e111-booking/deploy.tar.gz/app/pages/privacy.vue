<script setup lang="ts">
useHead({
  title: '隱私權政策 - 御手國醫養生會館',
})
</script>

<template>
  <div class="max-w-4xl mx-auto py-12 px-6 font-sans text-gray-800 leading-relaxed">
    <h1 class="text-3xl font-serif font-bold text-brand-dark mb-8 border-b pb-4">隱私權政策</h1>
    
    <div class="space-y-6">
      <section>
        <h2 class="text-xl font-bold mb-2">1. 隱私權保護政策的適用範圍</h2>
        <p>歡迎您使用御手國醫養生會館（以下簡稱本會館）的預約服務。隱私權保護政策內容，包括本會館如何處理在您使用網站服務時收集到的個人識別資料。本隱私權保護政策不適用於本會館以外的相關連結網站，也不適用於非本會館所委託或參與管理的人員。</p>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">2. 個人資料的蒐集、處理及利用方式</h2>
        <p>當您造訪本會館網站或使用本會館所提供之預約功能服務時，我們將視該服務功能性質，請您提供必要的個人資料，並在該特定目的範圍內處理及利用您的個人資料；非經您書面同意，本會館不會將個人資料用於其他用途。</p>
        <ul class="list-disc pl-5 mt-2 space-y-1">
            <li>在您使用預約服務時，我們會保留您所提供的姓名、電話號碼、電子郵件地址及使用時間等，以便進行預約確認及聯絡。</li>
            <li>為了提供精確的服務，我們會將收集的問卷調查內容進行統計與分析，分析結果之統計數據或說明文字呈現，除供內部研究外，我們會視需要公佈統計數據及說明文字，但不涉及特定個人之資料。</li>
        </ul>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">3. 資料之保護</h2>
        <p>本會館主機均設有防火牆、防毒系統等相關的各項資訊安全設備及必要的安全防護措施，加以保護網站及您的個人資料採用嚴格的保護措施，只由經過授權的人員才能接觸您的個人資料，相關處理人員皆簽有保密合約，如有違反保密義務者，將會受到相關的法律處分。</p>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">4. 網站對外的相關連結</h2>
        <p>本會館網站的網頁提供其他網站的網路連結，您也可經由本會館網站所提供的連結，點選進入其他網站。但該連結網站不適用本會館的隱私權保護政策，您必須參考該連結網站中的隱私權保護政策。</p>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">5. 與第三人共用個人資料之政策</h2>
        <p>本會館絕不會提供、交換、出租或出售任何您的個人資料給其他個人、團體、私人企業或公務機關，但有法律依據或合約義務者，不在此限。</p>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">6. Cookie 之使用</h2>
        <p>為了提供您最佳的服務，本網站可能會在您的電腦中放置並取用我們的 Cookie，若您不願接受 Cookie 的寫入，您可在您使用的瀏覽器功能項中設定隱私權等級為高，即可拒絕 Cookie 的寫入，但可能會導至網站某些功能無法正常執行 。</p>
      </section>

      <section>
        <h2 class="text-xl font-bold mb-2">7. 隱私權保護政策之修正</h2>
        <p>本會館隱私權保護政策將因應需求隨時進行修正，修正後的條款將刊登於網站上。</p>
      </section>
    </div>

    <div class="mt-12 text-center">
       <NuxtLink to="/" class="px-6 py-2 bg-brand-dark text-white rounded hover:bg-black transition-colors">返回首頁</NuxtLink>
    </div>
  </div>
</template>
